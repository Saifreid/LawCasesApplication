package edu.psu.ist.view;

import edu.psu.ist.controller.CaseListController;
import edu.psu.ist.controller.UserCaseListController;
import edu.psu.ist.model.Case;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class UserCaseListView extends JFrame{
    private JPanel caseListPanel;
    private JList caseJList;
    private JButton viewCaseButton;
    private JButton dashboardButton;
    public static final int FRAME_WIDTH = 500;


    public static final int FRAME_HEIGHT = 600;

    private UserCaseListController caseListController;

    private List<Case> cases = new ArrayList<>();


    public UserCaseListView(UserCaseListController userCaseListController){
        this.caseListController = userCaseListController;
        createCaseListComponents();
    }





    private void createCaseListComponents() {
        this.add(caseListPanel);
        this.setSize(FRAME_WIDTH,FRAME_HEIGHT);
        this.setTitle("Case List");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    public void updateCaseList(List<Case> cases){
        caseJList.setListData(cases.toArray());
    }

    public JButton getViewCaseButton(){
        return this.viewCaseButton;
    }


    public JButton getDashboardButton(){
        return this.dashboardButton;
    }


    public Case getSelectedCase(){
        System.out.println(caseJList.getSelectedValue());
        return (Case) caseJList.getSelectedValue();
    }


}
