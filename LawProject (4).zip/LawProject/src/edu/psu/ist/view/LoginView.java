package edu.psu.ist.view;

import edu.psu.ist.controller.LoginController;

import javax.swing.*;

public class LoginView extends JFrame{
    private JPanel loginPanel;
    private JPasswordField passwordJPassword;
    private JTextField usernameJText;
    private JLabel usernameJLabel;
    private JLabel passwordJLabel;
    private JLabel authenticationJLabel;
    private JButton loginButton;
    private JButton signUpButton;

    public static final int FRAME_WIDTH = 500;


    public static final int FRAME_HEIGHT = 600;

    private LoginController loginController;


    public LoginView(LoginController loginController){
        this.loginController = loginController;
        createLoginComponents();
    }



    private void createLoginComponents() {
        this.add(loginPanel);
        this.setSize(FRAME_WIDTH,FRAME_HEIGHT);
        this.setTitle("Login");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    public JButton getLoginButton(){
        return this.loginButton;
    }

    public JButton getSignupButton(){
        return this.signUpButton;
    }

    public JTextField getUsernameJText(){
        return this.usernameJText;
    }

    public JPasswordField getPasswordJPassword(){
        return this.passwordJPassword;
    }

    public void setMessage(String message){
        this.authenticationJLabel.setText(message);
    }

}
