package edu.psu.ist.view;

import edu.psu.ist.controller.CaseController;
import edu.psu.ist.model.Case;
import edu.psu.ist.model.Document;
import edu.psu.ist.model.User;

import javax.swing.*;
import java.util.List;

import static javax.swing.JOptionPane.showMessageDialog;

public class CaseView extends JFrame{
    private JList documentList;
    private JLabel caseNameJLabel;
    private JLabel caseTypeJLabel;
    private JLabel caseStatusJLabel;
    private JButton addDocumentButton;
    private JButton viewDocumentButton;
    private JButton deleteDocumentButton;
    private JPanel casePanel;
    private JButton closeButton;
    private javax.swing.JScrollPane JScrollPane;

    public static final int FRAME_WIDTH = 500;


    public static final int FRAME_HEIGHT = 600;

    private CaseController caseController;




    public CaseView(CaseController caseController){
        this.caseController = caseController;
        createCaseComponents();

    }

    public void updateCaseView(Case selectedCase){
        documentList.setListData(selectedCase.getDocumentList().toArray());
        caseNameJLabel.setText("Case: " + selectedCase.getCaseName());
        caseStatusJLabel.setText("Status: " + selectedCase.getStatus());
        caseTypeJLabel.setText("Type: " + selectedCase.getCaseType());
    }

    private void createCaseComponents() {
        this.add(casePanel);
        this.setSize(FRAME_WIDTH,FRAME_HEIGHT);
        this.setTitle("Case");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    public JButton getAddDocumentButton(){
        return this.addDocumentButton;
    }

    public JButton getViewDocumentButton(){
        return this.viewDocumentButton;
    }

    public JButton getCloseButton(){
        return this.closeButton;
    }

    public JButton getDeleteDocumentButton(){
        return this.deleteDocumentButton;
    }

    public void closeCase(){
        this.dispose();
    }

    public void setDocumentList(Case selectedCase){
        this.documentList.setListData(selectedCase.getDocumentList().toArray());
    }

    public Document getSelectedDocument(){
        Object selectedValue = documentList.getSelectedValue();
        if (selectedValue == null) {

            return null;

        } else {
            System.out.println(documentList.getSelectedValue());
            return (Document) documentList.getSelectedValue();
        }


    }
}
