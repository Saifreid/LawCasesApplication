package edu.psu.ist.view;

import edu.psu.ist.controller.AdminDashboardController;

import javax.swing.*;

public class AdminDashboardView extends JFrame{
    private JPanel adminDashboardPanel;
    private JButton viewCasesButton;
    private JButton courtScheduleButton;
    private JButton changeAccessRolesButton;
    private JLabel titleJLabel;
    private JLabel userJLabel;
    private JButton signoutButton;


    private AdminDashboardController adminDashboardController;

    public static final int FRAME_WIDTH = 500;


    public static final int FRAME_HEIGHT = 600;



    public AdminDashboardView(AdminDashboardController adminDashboardController){
        this.adminDashboardController = adminDashboardController;
        createDashboardComponents();

    }
    private void createDashboardComponents() {
        this.add(adminDashboardPanel);
        this.setSize(FRAME_WIDTH,FRAME_HEIGHT);
        this.setTitle("Admin Dashboard");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);


    }

    public JButton getViewCasesJButton(){
        return this.viewCasesButton;
    }

    public JButton getSignoutButton(){
        return this.signoutButton;
    }

    public JButton getCourtScheduleButton(){
        return this.courtScheduleButton;
    }

    public JButton getChangeAccessRolesButton(){
        return this.changeAccessRolesButton;
    }

    public void setName(String username){
        this.userJLabel.setText("User: " + username);
    }
    public void closeWindow(){
        this.setVisible(false);
    }

}
