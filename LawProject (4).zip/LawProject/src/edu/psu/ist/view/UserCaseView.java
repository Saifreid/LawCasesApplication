package edu.psu.ist.view;

import edu.psu.ist.controller.UserCaseController;
import edu.psu.ist.model.Case;
import edu.psu.ist.model.Document;

import javax.swing.*;

public class UserCaseView extends JFrame{
    private JPanel casePanel;
    private JList documentList;
    private JButton viewDocumentButton;
    private JButton closeButton;
    private JLabel caseStatusJLabel;
    private JLabel caseTypeJLabel;
    private JLabel caseNameJLabel;

    public static final int FRAME_WIDTH = 500;


    public static final int FRAME_HEIGHT = 600;

    UserCaseController userCaseController;

    public UserCaseView(UserCaseController userCaseController){
        this.userCaseController = userCaseController;
        createCaseComponents();
    }



    public void updateCaseView(Case selectedCase){
        documentList.setListData(selectedCase.getDocumentList().toArray());
        caseNameJLabel.setText("Case: " + selectedCase.getCaseName());
        caseStatusJLabel.setText("Status: " + selectedCase.getStatus());
        caseTypeJLabel.setText("Type: " + selectedCase.getCaseType());
    }

    private void createCaseComponents() {
        this.add(casePanel);
        this.setSize(FRAME_WIDTH,FRAME_HEIGHT);
        this.setTitle("Case");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }


    public JButton getViewDocumentButton(){
        return this.viewDocumentButton;
    }

    public JButton getCloseButton(){
        return this.closeButton;
    }


    public void closeCase(){
        this.dispose();
    }

    public void setDocumentList(Case selectedCase){
        this.documentList.setListData(selectedCase.getDocumentList().toArray());
    }

    public Document getSelectedDocument(){
        Object selectedValue = documentList.getSelectedValue();
        if (selectedValue == null) {

            return null;

        } else {
            System.out.println(documentList.getSelectedValue());
            return (Document) documentList.getSelectedValue();
        }


    }


}
