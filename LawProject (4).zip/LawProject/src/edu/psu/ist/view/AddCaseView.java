package edu.psu.ist.view;

import edu.psu.ist.controller.AddCaseController;
import edu.psu.ist.controller.CaseListController;
import edu.psu.ist.model.Case;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class AddCaseView extends JFrame{
    private JButton addCaseButton;
    private JButton cancelButton;
    private JTextField caseNameJText;
    private JTextField caseTypeJText;
    private JTextField caseStatusJText;
    private JPanel addCasePanel;


    public static final int FRAME_WIDTH = 500;


    public static final int FRAME_HEIGHT = 600;

    private AddCaseController addCaseController;




    public AddCaseView(AddCaseController addCaseController){
        this.addCaseController = addCaseController;
        createCaseListComponents();
    }





    private void createCaseListComponents() {
        this.add(addCasePanel);
        this.setSize(FRAME_WIDTH,FRAME_HEIGHT);
        this.setTitle("Add Case");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    public JButton getAddCaseButton(){
        return this.addCaseButton;
    }

    public JButton getCancelButton(){
        return this.cancelButton;
    }

    public String getCaseName(){
        return this.caseNameJText.getText();
    }

    public String getCaseStatus(){
        return this.caseStatusJText.getText();
    }

    public String getCaseType(){
        return this.caseTypeJText.getText();
    }

}
