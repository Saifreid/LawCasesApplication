package edu.psu.ist.view;

import edu.psu.ist.controller.UserDashboardController;

import javax.swing.*;

public class UserDashboardView extends JFrame{
    private JPanel DashboardPanel;
    private JButton viewCasesButton;
    private JButton courtScheduleButton;
    private JLabel titleJLabel;
    private JLabel userJLabel;
    private JLabel roleJLabel;
    private JButton signoutButton;

    public static final int FRAME_WIDTH = 500;


    public static final int FRAME_HEIGHT = 600;

    private UserDashboardController userDashboardController;

    public UserDashboardView(UserDashboardController userDashboardController){
        this.userDashboardController = userDashboardController;
        createDashboardComponents();
    }



    private void createDashboardComponents() {
        this.add(DashboardPanel);
        this.setSize(FRAME_WIDTH,FRAME_HEIGHT);
        this.setTitle("User Dashboard");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);


    }

    public JButton getViewCasesButton(){
        return this.viewCasesButton;
    }

    public JButton getSignoutButton(){
        return this.signoutButton;
    }

    public JButton getCourtScheduleButton(){
        return this.courtScheduleButton;
    }

    public void setName(String username){
        this.userJLabel.setText("User: " + username);
    }

    public void setRole(String role){
        this.roleJLabel.setText("Role: " + role);
    }

}
