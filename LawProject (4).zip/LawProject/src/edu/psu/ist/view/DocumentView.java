package edu.psu.ist.view;

import edu.psu.ist.controller.CaseController;
import edu.psu.ist.controller.DocumentController;
import edu.psu.ist.model.Document;

import javax.swing.*;

public class DocumentView extends JFrame{
    private JPanel documentPanel;
    private JLabel titleJLabel;
    private JButton closeDocumentButton;
    private JLabel documentContentJLabel;

    public static final int FRAME_WIDTH = 500;


    public static final int FRAME_HEIGHT = 600;

    private DocumentController documentController;

    public DocumentView(DocumentController documentController){
        this.documentController = documentController;
        creatDocumentComponents();

    }

    public void creatDocumentComponents(){
        this.add(documentPanel);
        this.setSize(FRAME_WIDTH,FRAME_HEIGHT);
        this.setTitle("Document");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    public JButton getCloseDocumentButton(){
        return this.closeDocumentButton;
    }

    public void setTitleJLabel(String title){
        this.titleJLabel.setText("Title: " + title);
    }

    public void setDocumentContentJLabel(String content){
        this.documentContentJLabel.setText(content);
    }
}
