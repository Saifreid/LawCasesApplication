package edu.psu.ist.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;

public class CalendarView extends JFrame {
    private JButton[][] days;
    private JLabel monthLabel;
    private JPanel calendarPanel;
    private JTextArea eventTextArea;
    private JButton doneButton;

    public CalendarView() {
        setTitle("Calendar");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 500);

        monthLabel = new JLabel("May");
        calendarPanel = new JPanel(new GridLayout(5, 7)); // assuming a 5x7 grid for simplicity
        eventTextArea = new JTextArea(5, 20); // Text area to display events
        doneButton = new JButton("Done");

        add(monthLabel, BorderLayout.NORTH);
        add(calendarPanel, BorderLayout.CENTER);
        add(new JScrollPane(eventTextArea), BorderLayout.SOUTH); // Add event text area with scroll pane


        days = new JButton[5][7];
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 7; j++) {
                JButton button = new JButton("");
                calendarPanel.add(button);
                days[i][j] = button;
            }
        }

        add(doneButton, BorderLayout.EAST);
        setVisible(true);
    }

    public void setMonthLabel(String month) {
        monthLabel.setText(month);
    }

    public void setDay(int row, int col, String text, ActionListener listener) {
        days[row][col].setText(text);
        if (listener != null) {
            days[row][col].addActionListener(listener);
        }
    }

    public void updateEvents(List<String> events) {
        eventTextArea.setText(""); // Clear existing text
        for (String event : events) {
            eventTextArea.append(event + "\n"); // Append each event to the text area
        }
    }

    public JButton getDoneButton(){
        return this.doneButton;
    }
}