package edu.psu.ist.view;

import edu.psu.ist.controller.CaseListController;
import edu.psu.ist.model.Case;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class CaseListView extends JFrame{
    private JList caseJList;
    private JPanel caseListPanel;
    private JButton viewCaseButton;
    private JButton deleteCaseButton;
    private JButton dashboardButton;
    private JButton addCaseButton;
    public static final int FRAME_WIDTH = 500;


    public static final int FRAME_HEIGHT = 600;

    private CaseListController caseListController;

    private List<Case> cases = new ArrayList<>();


    public CaseListView(CaseListController caseListController){
        this.caseListController = caseListController;
        createCaseListComponents();
    }





    private void createCaseListComponents() {
        this.add(caseListPanel);
        this.setSize(FRAME_WIDTH,FRAME_HEIGHT);
        this.setTitle("Case List");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    public void updateCaseList(List<Case> cases){
        caseJList.setListData(cases.toArray());
    }

    public JButton getViewCaseButton(){
        return this.viewCaseButton;
    }

    public JButton getDeleteCaseButton(){
        return this.deleteCaseButton;
    }

    public JButton getDashboardButton(){
        return this.dashboardButton;
    }

    public JButton getAddCaseButton(){
        return this.addCaseButton;
    }

    public Case getSelectedCase(){
        System.out.println(caseJList.getSelectedValue());
        return (Case) caseJList.getSelectedValue();
    }
}
