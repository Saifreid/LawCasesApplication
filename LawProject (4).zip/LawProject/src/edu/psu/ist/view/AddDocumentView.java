package edu.psu.ist.view;

import edu.psu.ist.controller.AddDocumentController;

import javax.swing.*;

public class AddDocumentView extends JFrame{
    private JPanel addDocumentPanel;
    private JTextArea documentContentJText;
    private JTextField documentTitleJText;
    private JButton cancelButton;
    private JButton addDocumentButton;

    public static final int FRAME_WIDTH = 500;


    public static final int FRAME_HEIGHT = 600;

    private AddDocumentController addDocumentController;


    public AddDocumentView(AddDocumentController addDocumentController){
        this.addDocumentController = addDocumentController;
        createAddDocumentViewComponents();
    }

    public void createAddDocumentViewComponents(){
        this.add(addDocumentPanel);
        this.setSize(FRAME_WIDTH,FRAME_HEIGHT);
        this.setTitle("Add Document");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    public JButton getCancelButton(){
        return this.cancelButton;
    }

    public JButton getAddDocumentButton(){
        return this.addDocumentButton;
    }

    public String getDocumentTitle(){
        return this.documentTitleJText.getText();
    }

    public String getDocumentContent(){
        return this.documentContentJText.getText();
    }




}
