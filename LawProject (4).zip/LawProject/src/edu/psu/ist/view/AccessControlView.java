package edu.psu.ist.view;

import edu.psu.ist.controller.AccessControlController;

import javax.swing.*;

public class AccessControlView extends JFrame{
    private JPanel accessControlPanel;
    private JTextField usernameInputText;
    private JTextField roleInputText;
    private JButton updateUserButton;
    private JButton dashboardButton;
    private JLabel newRoleJLabel;
    private JLabel usernameJLabel;


    public static final int FRAME_WIDTH = 500;


    public static final int FRAME_HEIGHT = 600;

    private AccessControlController accessControlController;




    public AccessControlView(AccessControlController accessControlController){
        this.accessControlController = accessControlController;
        createComponents();

    }

    private void createComponents(){
        this.add(accessControlPanel);
        this.setSize(FRAME_WIDTH,FRAME_HEIGHT);
        this.setTitle("Access Control");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    public JButton getDashboardButton(){
        return this.dashboardButton;
    }

    public JButton getUpdateUserButton(){
        return  this.updateUserButton;
    }

    public String getUsernameInput(){
        return this.usernameInputText.getText();
    }

    public String getNewRole(){
        return this.roleInputText.getText();
    }


}
