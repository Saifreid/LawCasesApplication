package edu.psu.ist.controller;

import edu.psu.ist.model.Case;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class CasePersistenceController {
    private String fileName = "Cases.txt";
    private List<Case> cases = new ArrayList<>();


    public CasePersistenceController(){
        readCasesFile();
        if(cases.isEmpty()){
            createInitialElements();
            writeCasesFile();
        }

    }

    public List<Case> getCases() {
        return cases;
    }

    public void writeCasesFile(){
        FileOutputStream fos = null;
        ObjectOutputStream out = null;
        try{
            fos = new FileOutputStream(fileName);
            out = new ObjectOutputStream(fos);
            out.writeObject(cases);
            out.close();
            System.out.println("Successful in writing to file");

        }catch(IOException e){
            System.out.println("Caught exception while writing to file" + e);
        }
    }

    public void readCasesFile(){
        FileInputStream fis = null;
        ObjectInputStream in = null;
        try{
            fis = new FileInputStream(fileName);
            in = new ObjectInputStream(fis);
            cases = (ArrayList) in.readObject();
            in.close();
        }catch(IOException | ClassNotFoundException e){
            System.out.println("Caught exception while reading from file: " + e.getMessage());
        }
        System.out.println("Successful in Reading from file");
    }

    public void createInitialElements(){
        Case case1 = new Case(1,"Jerry vs. Manny","Tax Evasion","Active");
        Case case2 = new Case(2, "Harold vs. Crayon", "Murder", "Inactive");
        cases.add(case1);
        cases.add(case2);
    }


}
