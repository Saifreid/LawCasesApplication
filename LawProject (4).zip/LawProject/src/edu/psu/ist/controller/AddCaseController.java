package edu.psu.ist.controller;

import edu.psu.ist.model.Case;
import edu.psu.ist.model.User;
import edu.psu.ist.view.AddCaseView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import static javax.swing.JOptionPane.showMessageDialog;

public class AddCaseController implements ActionListener {

    private AddCaseView addCaseView;
    private User user;
    private List<Case> cases = new ArrayList<>();
    private CaseListController caseListController;

    public AddCaseController(User user, CaseListController caseListController){
        this.caseListController = caseListController;
        this.cases = caseListController.getCasePersistenceController().getCases();
        this.user = user;
        this.addCaseView = new AddCaseView(this);
        addActionListeners();

    }


    private void addActionListeners(){
        this.addCaseView.getAddCaseButton().addActionListener(this);
        this.addCaseView.getCancelButton().addActionListener(this);
    }




    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == this.addCaseView.getAddCaseButton()) {
            if(addCaseView.getCaseType().isEmpty() || addCaseView.getCaseName().isEmpty() || addCaseView.getCaseStatus().isEmpty()){
                showMessageDialog(null, "Missing information");
                return;
            }

            cases.add(new Case(cases.size() + 1, addCaseView.getCaseName(), addCaseView.getCaseType(), addCaseView.getCaseStatus()));
            caseListController.getCasePersistenceController().writeCasesFile();
            this.caseListController.updateView();
            this.addCaseView.dispose();
        }
        if (e.getSource() == this.addCaseView.getCancelButton()) {
            this.addCaseView.dispose();
        }
    }

}
