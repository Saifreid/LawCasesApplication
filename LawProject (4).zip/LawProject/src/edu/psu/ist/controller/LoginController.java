package edu.psu.ist.controller;

import edu.psu.ist.model.*;
import edu.psu.ist.view.AdminDashboardView;
import edu.psu.ist.view.LoginView;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class LoginController implements ActionListener {
    private LoginView loginView;

    private List<User> users = new ArrayList<>();

    private UserPersistenceController userPersistenceController;


    public LoginController(){

        this.userPersistenceController = new UserPersistenceController();
        this.loginView = new LoginView(this);
        this.users = userPersistenceController.getUsers();
        addActionListeners();

    }

    public void validateLogin(String targetUsername, String targetPassword){
        System.out.println("In validateLogin: targetPassword = " + targetPassword);
        for(User user:this.users ){
            if (user.getUsername().equals(targetUsername)){
                if (user.getPassword().equals(targetPassword) && user.isAdmin()){
                    System.out.println("Opening Admin Dashboard");
                    new AdminDashboardController(user);
                    loginView.dispose();
                    break;


                }
                else if (user.getPassword().equals(targetPassword)){
                    System.out.println("Opening User Dashboard");
                    new UserDashboardController(user);
                    loginView.dispose();
                }

            }

        }
        loginView.setMessage("No User Found or Incorrect Login");

    }

    private void registerUser(String username, String password){
        for(User user:this.users){
            if (user.getUsername().equals(username)){
                loginView.setMessage("Cannot create user, user already exists");
                return;
            }
        }
        this.users.add(new User(username, password));
        userPersistenceController.writeUsersFile();
    }

    private void addActionListeners(){
        loginView.getLoginButton().addActionListener(this);
        loginView.getSignupButton().addActionListener(this);
    }


    @Override
    public void actionPerformed(ActionEvent e) {


        if (e.getSource() == loginView.getLoginButton()){
            if (loginView.getUsernameJText().getText().isEmpty() || new String(loginView.getPasswordJPassword().getPassword()).isEmpty()){
                loginView.setMessage("Missing Field Required!");
                return;
            }
            System.out.println("Login Button Pushed!");
            validateLogin(loginView.getUsernameJText().getText(), new String(loginView.getPasswordJPassword().getPassword()));
        }
        if (e.getSource() == loginView.getSignupButton()){
            if (loginView.getUsernameJText().getText().isEmpty() || new String(loginView.getPasswordJPassword().getPassword()).isEmpty()){
                loginView.setMessage("Missing Field Required!");
                return;
            }
            System.out.println("Signup Button Pushed!");
            registerUser(loginView.getUsernameJText().getText(), new String(loginView.getPasswordJPassword().getPassword()));
        }

    }
}
