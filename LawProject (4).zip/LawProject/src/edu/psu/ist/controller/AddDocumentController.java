package edu.psu.ist.controller;

import edu.psu.ist.model.Case;
import edu.psu.ist.model.Document;
import edu.psu.ist.model.User;
import edu.psu.ist.view.AddCaseView;
import edu.psu.ist.view.AddDocumentView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import static javax.swing.JOptionPane.showMessageDialog;

public class AddDocumentController implements ActionListener {

    private AddDocumentView addDocumentView;
    private User user;
    private List<Document> documents = new ArrayList<>();
    private CaseController caseController;
    private Case selectedCase;

    public AddDocumentController(User user, Case selectedCase, CaseController caseController){
        this.user = user;
        this.caseController = caseController;
        this.addDocumentView = new AddDocumentView(this);
        this.selectedCase = selectedCase;
        this.documents = selectedCase.getDocumentList();
        addActionListeners();
    }


    private void addActionListeners(){
        this.addDocumentView.getAddDocumentButton().addActionListener(this);
        this.addDocumentView.getCancelButton().addActionListener(this);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addDocumentView.getAddDocumentButton()){
            if(addDocumentView.getDocumentContent().isEmpty() || addDocumentView.getDocumentTitle().isEmpty() || addDocumentView.getDocumentContent().equals("Context:")){
                showMessageDialog(null, "Missing information");
                return;
            }
            selectedCase.addDocument(new Document(selectedCase.getDocumentList().size(), addDocumentView.getDocumentTitle(), addDocumentView.getDocumentContent()));
            caseController.getCasePersistenceController().writeCasesFile();
            this.caseController.getCaseView().updateCaseView(selectedCase);
            addDocumentView.dispose();
        }

        if (e.getSource() == addDocumentView.getCancelButton()) {
            addDocumentView.dispose();
        }
    }

}
