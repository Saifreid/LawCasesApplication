package edu.psu.ist.controller;


import edu.psu.ist.model.CalendarModel;
import edu.psu.ist.model.CalendarModelListener;
import edu.psu.ist.view.CalendarView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JOptionPane;

public class CalendarController implements CalendarModelListener, ActionListener {
    private CalendarModel model;
    private CalendarView view;

    public CalendarController(CalendarModel model, CalendarView view) {
        this.model = model;
        this.view = view;
        model.registerListener(this);

        addActionListeners();
        updateView();

    }

    public void updateView() {
// view.clearCalendar();
        String[][] monthData = {{"1", "2", "3", "4", "5", "6", "7"},
                {"8", "9", "10", "11", "12", "13", "14"},
                {"15", "16", "17", "18", "19", "20", "21"},
                {"22", "23", "24", "25", "26", "27", "28"},
                {"29", "30", "", "", "", "", ""}};

        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 7; j++) {
                String day = monthData[i][j].toString();
                if (!day.isEmpty()) {
                    view.setDay(i, j, day, new ActionListener(){
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            String event = JOptionPane.showInputDialog("Enter event:");
                            if (event != null && !event.isEmpty()) {
                                model.addEvent("May " + day + ": " + event);
                                updateView();
                                view.updateEvents(model.getEvents());
                            }
                        }
                    });
                }
            }
        }
        List<String> events = model.getEvents();
// Assuming events are added for each day
// Logic to update the calendar with events
    }

    public static void main(String[] args) {
        CalendarModel model = new CalendarModel();
        CalendarView view = new CalendarView();
        CalendarController controller = new CalendarController(model, view);
    }

    private void addActionListeners(){
        view.getDoneButton().addActionListener(this);
    }

    @Override
    public void eventsUpdated() {
        updateView();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == view.getDoneButton()){
            view.dispose();
        }
    }
}