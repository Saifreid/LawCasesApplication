package edu.psu.ist.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;


import edu.psu.ist.model.*;
import edu.psu.ist.view.AddCaseView;
import edu.psu.ist.view.CaseListView;

import static javax.swing.JOptionPane.showMessageDialog;

public class CaseListController implements ActionListener {
    private User user;
    private List<Case> cases = new ArrayList<>();
    private CasePersistenceController casePersistenceController;
    private CaseListView caseListView;


    public CaseListController(User user){
        this.user = user;
        this.casePersistenceController = new CasePersistenceController();
        this.cases = casePersistenceController.getCases();
        this.caseListView = new CaseListView(this);
        caseListView.updateCaseList(cases);
        addActionListeners();
    }

    public void addActionListeners(){
        caseListView.getDeleteCaseButton().addActionListener(this);
        caseListView.getViewCaseButton().addActionListener(this);
        caseListView.getDashboardButton().addActionListener(this);
        caseListView.getAddCaseButton().addActionListener(this);
    }


    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource() == caseListView.getViewCaseButton()){
            Case mySelectedCase = caseListView.getSelectedCase();
            if(mySelectedCase == null){
                showMessageDialog(null, "Document not Found");
                return;
            }else{
                System.out.println("View Case Button Pushed");
                new CaseController(user, caseListView.getSelectedCase(), casePersistenceController);
            }


        }
        if(e.getSource() == caseListView.getDeleteCaseButton()){
            Case mySelectedCase = caseListView.getSelectedCase();
            if(mySelectedCase == null){
                showMessageDialog(null, "Document not Found");
                return;
            }else {
                System.out.println("Delete Case Button Pushed");
                cases.remove(caseListView.getSelectedCase());
                casePersistenceController.writeCasesFile();
                caseListView.updateCaseList(cases);
            }
        }
        if(e.getSource() == caseListView.getDashboardButton()){
            System.out.println("Dashboard Butoon Pushed");
            if(user.isAdmin()){
                new AdminDashboardController(user);
                caseListView.dispose();

                return;
            }
            else{
                new UserDashboardController(user);
                caseListView.dispose();
            }
        }
        if(e.getSource() == caseListView.getAddCaseButton()){
            new AddCaseController(this.user,this);
        }
    }


    public void updateView(){
        this.caseListView.updateCaseList(cases);
    }

    public CasePersistenceController getCasePersistenceController(){
        return this.casePersistenceController;
    }
}
