package edu.psu.ist.controller;

import edu.psu.ist.model.Case;
import edu.psu.ist.model.User;
import edu.psu.ist.view.UserCaseListView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import static javax.swing.JOptionPane.showMessageDialog;

public class UserCaseListController implements ActionListener {

    private User user;
    private List<Case> cases = new ArrayList<>();
    private CasePersistenceController casePersistenceController;
    private UserCaseListView caseListView;


    public UserCaseListController(User user){
        this.user = user;
        this.casePersistenceController = new CasePersistenceController();
        this.cases = casePersistenceController.getCases();
        this.caseListView = new UserCaseListView(this);
        caseListView.updateCaseList(cases);
        addActionListeners();
    }

    public void addActionListeners(){
        caseListView.getViewCaseButton().addActionListener(this);
        caseListView.getDashboardButton().addActionListener(this);
    }


    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource() == caseListView.getViewCaseButton()){
            Case mySelectedCase = caseListView.getSelectedCase();
            if(mySelectedCase == null){
                showMessageDialog(null, "Document not Found");
                return;
            }else{
                System.out.println("View Case Button Pushed");
                new UserCaseController(user, caseListView.getSelectedCase(), casePersistenceController);
            }


        }
        if(e.getSource() == caseListView.getDashboardButton()){
            System.out.println("Dashboard Button Pushed");
            if(user.isAdmin()){
                new AdminDashboardController(user);
                caseListView.dispose();

                return;
            }
            else{
                new UserDashboardController(user);
                caseListView.dispose();
            }
        }
    }


    public void updateView(){
        this.caseListView.updateCaseList(cases);
    }

    public CasePersistenceController getCasePersistenceController(){
        return this.casePersistenceController;
    }
}
