package edu.psu.ist.controller;

import edu.psu.ist.model.Document;
import edu.psu.ist.model.User;
import edu.psu.ist.view.DocumentView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class DocumentController implements ActionListener {


    private DocumentView documentView;

    private User user;

    private Document document;


    public DocumentController(User user, Document document){
        this.user = user;
        this.documentView = new DocumentView(this);
        this.document = document;
        addActionListeners();
        updateView();
    }

    private void addActionListeners(){
        this.documentView.getCloseDocumentButton().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == documentView.getCloseDocumentButton()){
            documentView.dispose();
        }
    }

    private void updateView(){
        documentView.setDocumentContentJLabel(document.getContent());
        documentView.setTitleJLabel(document.getTitle());
    }

}
