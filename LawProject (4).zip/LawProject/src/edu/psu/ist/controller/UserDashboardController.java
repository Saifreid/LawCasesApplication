package edu.psu.ist.controller;


import edu.psu.ist.model.*;
import edu.psu.ist.view.CalendarView;
import edu.psu.ist.view.UserDashboardView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class UserDashboardController implements ActionListener{

    private UserDashboardView dashboardView;

    private User user;


    public UserDashboardController(User user){
        this.user = user;
        dashboardView = new UserDashboardView(this);
        dashboardView.setName(user.getUsername());
        dashboardView.setRole(user.getRole().toString());
        addActionListeners();
    }


    public void addActionListeners(){
        dashboardView.getViewCasesButton().addActionListener(this);
        dashboardView.getSignoutButton().addActionListener(this);
        dashboardView.getCourtScheduleButton().addActionListener(this);
    }



    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == dashboardView.getCourtScheduleButton()) {
            System.out.println("Court Schedule Button Pushed!");
            CalendarModel model = new CalendarModel();
            CalendarView view = new CalendarView();
            new CalendarController(model, view);

        }
        if (e.getSource() == dashboardView.getSignoutButton()) {
            System.out.println("Signout Button Pushed!");
            new LoginController();
            dashboardView.dispose();

        }
        if (e.getSource() == dashboardView.getViewCasesButton()) {
            System.out.println("View Cases Button Pushed!");
            new UserCaseListController(user);
            dashboardView.dispose();
        }


    }

}
