package edu.psu.ist.controller;

import edu.psu.ist.model.CalendarModel;
import edu.psu.ist.model.User;
import edu.psu.ist.view.AdminDashboardView;
import edu.psu.ist.view.CalendarView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class AdminDashboardController implements ActionListener {
    private AdminDashboardView dashboardView;

    private User user;

    private List<User> users = new ArrayList<>();

    private UserPersistenceController userPersistenceController;

    public AdminDashboardController(User user){
        this.user = user;
        this.userPersistenceController = new UserPersistenceController();
        this.users = userPersistenceController.getUsers();
        dashboardView = new AdminDashboardView(this);
        dashboardView.setName(user.getUsername());
        addActionListeners();
    }



    public void addActionListeners(){
        dashboardView.getViewCasesJButton().addActionListener(this);
        dashboardView.getSignoutButton().addActionListener(this);
        dashboardView.getCourtScheduleButton().addActionListener(this);
        dashboardView.getChangeAccessRolesButton().addActionListener(this);
    }



    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == dashboardView.getCourtScheduleButton()) {
            System.out.println("Court Schedule Button Pushed!");
            CalendarModel model = new CalendarModel();
            CalendarView view = new CalendarView();
            new CalendarController(model, view);

        }
        if (e.getSource() == dashboardView.getSignoutButton()) {
            System.out.println("Signout Button Pushed!");
            new LoginController();
            dashboardView.dispose();

        }
        if (e.getSource() == dashboardView.getViewCasesJButton()) {
            System.out.println("View Cases Button Pushed!");
            new CaseListController(user);
            dashboardView.dispose();
        }
        if (e.getSource() == dashboardView.getChangeAccessRolesButton()) {
            System.out.println("Change Roles Button Pushed!");
            new AccessControlController(user);
            dashboardView.dispose();
        }

    }

}
