package edu.psu.ist.controller;

import edu.psu.ist.model.User;
import edu.psu.ist.view.AccessControlView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import static javax.swing.JOptionPane.showMessageDialog;

public class AccessControlController implements ActionListener {

    private User user;

    private AccessControlView accessControlView;

    private List<User> users = new ArrayList<>();

    private UserPersistenceController userPersistenceController;

    public AccessControlController(User user){
        this.userPersistenceController = new UserPersistenceController();
        this.user = user;
        this.accessControlView = new AccessControlView(this);
        this.users = userPersistenceController.getUsers();
        addActionListeners();

    }


    private void addActionListeners(){
        accessControlView.getUpdateUserButton().addActionListener(this);
        accessControlView.getDashboardButton().addActionListener(this);
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == accessControlView.getDashboardButton()){
            new AdminDashboardController(user);
            accessControlView.dispose();
        }
        if(e.getSource() == accessControlView.getUpdateUserButton()){
            System.out.println("In update user button");
            String selectedUser = accessControlView.getUsernameInput();
            String updateRole = accessControlView.getNewRole().toLowerCase();
            if (selectedUser.isEmpty() || updateRole.isEmpty()){
                showMessageDialog(null, "Missing information");
                return;
            }
            List<String> roles = new ArrayList<>();
            roles.add("admin");
            roles.add("attorney");
            if (!roles.contains(updateRole)){
                showMessageDialog(null, "Role doesn't exist use either admin, or attorney");
            }
            else{
                User updateUser = findUser(selectedUser);
                if (updateUser == null){
                    showMessageDialog(null, "No User Found");
                }else{
                    updateUser.updateRole(updateRole);
                    userPersistenceController.writeUsersFile();
                    showMessageDialog(null, "Updated role to: " + updateRole);
                }
            }
        }
    }
    private User findUser(String targetUser){
        System.out.println("Before findUserLoop");
        for(User myUser: users){
            System.out.println("In loop");
            if(myUser.getUsername().equals(targetUser)){
                return myUser;
            }
        }
        return null;
    }



}
