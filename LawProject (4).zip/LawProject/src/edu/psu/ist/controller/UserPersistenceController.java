package edu.psu.ist.controller;


import edu.psu.ist.model.*;
import java.util.ArrayList;
import java.util.List;
import java.io.*;



public class UserPersistenceController {
    private List<User> users = new ArrayList<>();

    private String fileName = "Users.txt";


    public UserPersistenceController(){
        readUsersFile();
        if(users.isEmpty()){
            createInitialElements();
            writeUsersFile();
        }

    }

    public List<User> getUsers() {
        return users;
    }

    public void writeUsersFile(){
        FileOutputStream fos = null;
        ObjectOutputStream out = null;
        try{
            fos = new FileOutputStream(fileName);
            out = new ObjectOutputStream(fos);
            out.writeObject(users);
            out.close();
            System.out.println("Successful in writing to file");

        }catch(IOException e){
            System.out.println("Caught exception while writing to file" + e);
        }
    }

    public void readUsersFile(){
        FileInputStream fis = null;
        ObjectInputStream in = null;
        try{
            fis = new FileInputStream(fileName);
            in = new ObjectInputStream(fis);
            users = (ArrayList) in.readObject();
            in.close();
        }catch(IOException | ClassNotFoundException e){
            System.out.println("Caught exception while reading from file: " + e.getMessage());
        }
        System.out.println("Successful in Reading from file");
    }

    private void createInitialElements(){
        //GameCompany Creation
        User adminUser1 = new AdminUser("admin","admin");
        User user1 = new User("User", "userpassword");

        users.add(adminUser1);
        users.add(user1);
    }

}
