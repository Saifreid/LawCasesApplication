package edu.psu.ist.controller;

import edu.psu.ist.model.Case;
import edu.psu.ist.model.Document;
import edu.psu.ist.model.User;
import edu.psu.ist.view.CaseView;
import edu.psu.ist.view.UserCaseView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static javax.swing.JOptionPane.showMessageDialog;

public class UserCaseController implements ActionListener {

    private Case selectedCase;

    private User user;

    private UserCaseView caseView;

    private CasePersistenceController casePersistenceController;


    public UserCaseController(User user, Case selectedCase, CasePersistenceController casePersistenceController){
        this.selectedCase = selectedCase;
        this.user = user;
        this.caseView = new UserCaseView(this);
        addActionListeners();
        this.caseView.updateCaseView(selectedCase);
    }

    private void addActionListeners(){
        caseView.getCloseButton().addActionListener(this);
        caseView.getViewDocumentButton().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {



        if (e.getSource() == caseView.getCloseButton()) {
            System.out.println("Case Close Button Pressed");
            caseView.dispose();
        }
        if (e.getSource() == caseView.getViewDocumentButton()) {
            System.out.println("View Document Button Pressed");
            Document mySelectedDocument = caseView.getSelectedDocument();
            if (mySelectedDocument == null){
                showMessageDialog(null, "Document not Found");
                return;
            }else {
                new DocumentController(this.user, this.caseView.getSelectedDocument());
            }
        }


    }

    public CasePersistenceController getCasePersistenceController(){
        return  this.casePersistenceController;
    }

    public UserCaseView getCaseView(){
        return this.caseView;
    }

}
