package edu.psu.ist.model;

public interface CalendarModelListener {
    void eventsUpdated();
}
