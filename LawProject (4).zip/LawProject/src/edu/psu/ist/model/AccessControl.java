package edu.psu.ist.model;

import java.io.Serializable;
import java.util.*;

public class AccessControl implements Serializable {



    private User user;
    private AccessLevel accessLevel;
    private Map<User, Set<AccessLevel>> accessMap;



    /**
     * Constructor
     */
    public AccessControl(User user, AccessLevel accessLevel) {
        this.user = user;
        this.accessLevel = accessLevel;
        this.accessMap = new HashMap<>();

    }



    public void AccessManager(Map<User, Set<AccessLevel>> accessMap) {
        this.accessMap = accessMap;
    }




    /**
     * List of privileges for document handling
     */
    public enum AccessLevel {
        READ, WRITE, DELETE
    }



    /**
     * Method to grant a specified User accessLevels
     * @param user
     * @param accessLevel
     */
    public void grantAccess(User user, AccessLevel accessLevel) {
        Set<AccessLevel> rights = accessMap.getOrDefault(user, new HashSet<>());
        rights.add(accessLevel);
        accessMap.put(user, rights);
    }


    /**
     * This is a method to check if a specified User has the accessLevel required for a task
     * @param user
     * @param accessLevel
     * @return
     */
    public boolean hasAccess(User user, AccessControl.AccessLevel accessLevel) {
        Set<AccessControl.AccessLevel> rights = accessMap.get(user);
        return rights != null && rights.contains(accessLevel);
    }
    public void allowAccess() {
        boolean accessGranted = hasAccess(user, accessLevel);
        if (accessGranted) {
            System.out.println("access granted");
        } else {
            System.out.println("no access granted");
        }
    }
}