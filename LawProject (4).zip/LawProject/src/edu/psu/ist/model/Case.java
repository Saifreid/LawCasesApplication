package edu.psu.ist.model;


import edu.psu.ist.controller.CasePersistenceController;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Case implements Serializable {

    private int caseId;
    private String caseName;
    private String caseType;
    private String status;
    private List<Document> documentList = new ArrayList<>();



    public Case(int caseId,String caseName, String caseType, String status) {
        this.caseId = caseId;
        this.caseName = caseName;
        this.caseType = caseType;
        this.status = status;
    }



    /**
     * Getter for CaseId
     *
     * @return
     */
    public int getCaseId() {
        return caseId;
    }

    /**
     * Setter for CaseId
     *
     * @param caseId
     */
    public void setCaseId(int caseId) {
        this.caseId = caseId;
    }

    /**
     * Getter for caseType
     *
     * @return
     */
    public String getCaseType() {
        return caseType;
    }

    /**
     * Setter for caseType
     *
     * @param caseType
     */
    public void setCaseType(String caseType) {
        this.caseType = caseType;
    }

    /**
     * @return
     */
    public String getStatus() {
        return status;
    }

    /**
     * Setter for status
     *
     * @param status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    public boolean addDocument(Document document){
        try{
            documentList.add(document);
            return true;
        }catch(Exception e){
            return false;
        }
    }

    public boolean deleteDocument(Document document){
        if(documentList.contains(document)){
            documentList.remove(document);
            System.out.println("Document removed from list");
            return true;
        }
        else{
            System.out.println("No Document found");
            return false;
        }
    }


    public List<Document> getDocumentList(){
        return this.documentList;
    }

    public String getCaseName(){
        return this.caseName;
    }




    @Override
    public String toString(){
        return caseName;
    }



}


