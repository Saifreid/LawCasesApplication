package edu.psu.ist.model;

import java.io.Serializable;

public class User implements Serializable {


    private String username;
    private String password;
    private UserRole role;



    public enum UserRole {
        ADMIN, CLERK, ATTORNEY, JUDGE
    }

    public User(String username, String password, UserRole role) {
        this.username = username;
        this.password = password;
        this.role = role;
    }

    public User(String username, String password) {
        this.username = username;
        this.password = password;
        this.role = UserRole.ATTORNEY;
    }
    /**
     * Getter for username
     * @return
     */
    public String getUsername() { return username; }

    /**
     * Setter for username
     * @param username
     */
    public void setUsername(String username) { this.username = username; }

    /**
     * Getter for password
     * @return
     */
    public String getPassword() { return password; }

    /**
     * Setter for password
     * @param password
     */
    public void setPassword(String password) { this.password = password; }

    /**
     * Getter for role
     * @return
     */
    public UserRole getRole() { return role; }

    /**
     * Setter for role
     * @param role
     */
    public void setRole(UserRole role) { this.role = role; }

    /**
     * returns true if the user role is "ADMIN" false otherwise
     * @return
     */
    public boolean isAdmin() { return this.role == UserRole.ADMIN; }

    /**
     * returns true if the user role is "CLERK" false otherwise
     * @return
     */
    public boolean isClerk() { return this.role == UserRole.CLERK; }

    /**
     * returns true if the user role is "ATTORNEY" false otherwise
     * @return
     */
    public boolean isAttorney() { return this.role == UserRole.ATTORNEY; }

    /**
     * returns true if the user role is "JUDGE" false otherwise
     * @return
     */
    public boolean isJudge() { return this.role == UserRole.JUDGE; }


    public void updateRole(String updateRole){
        if(updateRole.equals("admin")){
            this.role = UserRole.ADMIN;
        }
        else if(updateRole.equals("attorney")){
            this.role = UserRole.ATTORNEY;
        }
    }
}