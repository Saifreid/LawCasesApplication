package edu.psu.ist.model;

import java.util.ArrayList;
import java.util.List;

public class CalendarModel {
    private List<String> events;
    private List<CalendarModelListener> listeners;

    public CalendarModel() {
        events = new ArrayList<>();
        listeners = new ArrayList<>();
    }

    public void addEvent(String event) {
        events.add(event);
        notifyListeners();
    }

    public List<String> getEvents() {
        return events;
    }

    public void registerListener(CalendarModelListener listener) {
        listeners.add(listener);
    }

    private void notifyListeners() {
        for (CalendarModelListener listener : listeners) {
            listener.eventsUpdated();
        }
    }
}