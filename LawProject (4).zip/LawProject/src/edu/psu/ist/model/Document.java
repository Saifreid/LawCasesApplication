package edu.psu.ist.model;


import java.io.Serializable;
import java.time.LocalDateTime;
import edu.psu.ist.model.AccessControl;

public class Document implements Serializable {

    private int docId;
    private String title;
    private String content;
    private final LocalDateTime creationDate;
    private LocalDateTime lastModifiedDate;
    // Assuming AccessControl is defined and includes document-level permissions
    //accessControlController documentAccessControl;

    public Document(int docId, String title, String content) {
        this.docId = docId;
        this.title = title;
        this.content = content;
        this.creationDate = LocalDateTime.now();
        this.lastModifiedDate = LocalDateTime.now();

    }



    // Getters and Setters
    /**
     * Getter for docId
     * @return
     */
    public int getDocId() { return docId; }

    /**
     * Setter for docId
     * @param docId
     */
    public void setDocId(int docId) { this.docId = docId; }


    /**
     * Getter for title
     * @return
     */
    public String getTitle() { return title; }

    /**
     * Setter for title
     * @param title
     */
    public void setTitle(String title) { this.title = title; }

    /**
     * Getter for content
     * @return
     */
    public String getContent() { return content; }

    /**
     * Setter for content
     * @param content
     */
    public void setContent(String content) {
        this.content = content;
        this.lastModifiedDate = LocalDateTime.now();
    }

    /**
     * Getter for creationDate
     * @return
     */
    public LocalDateTime getCreationDate() { return creationDate; }

    /**
     * Getter for lastModifiedDate
     * @return
     */
    public LocalDateTime getLastModifiedDate() { return lastModifiedDate; }

    /**
     * Getter for documentAccessControl
     * @return
     */


    /**
     * Getter for documentAccessControl
     * @param documentAccessControl
     */


    // Additional functionality like update, delete can be added here
    /**
     * Setter method for content that also changes the lastModifiedDate
     * @param newContent
     */
    public void updateDocument(String newContent) {
        this.content = newContent;
        this.lastModifiedDate = LocalDateTime.now();
    }

    /**
     * Deletes a specified document by docId and returns true if successful
     * @param docId
     * @return
     */
    public static boolean deleteDocument(int docId) {
        return true; // Placeholder return value
    }

    @Override
    public String toString(){
        System.out.println("Printing document title");
        return this.title;
    }

}