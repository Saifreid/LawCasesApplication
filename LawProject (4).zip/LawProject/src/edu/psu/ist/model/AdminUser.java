package edu.psu.ist.model;

public class AdminUser extends User{



    public AdminUser(String username, String password) {
        super(username, password, UserRole.ADMIN);
    }


    @Override
    public boolean isAdmin(){
        return true;
    }

}