package edu.psu.ist.model;



import java.io.Serializable;
import java.util.Date;


/**
 *
 * @author josh
 */
public class CourtEvent implements Serializable {

    private Date date;
    private String time;
    private int courtId;
    private String judge;

    public CourtEvent(Date date, String time, int courtId, String judge) {
        this.date = date;
        this.time = time;
        this.courtId = courtId;
        this.judge = judge;
    }

    /**
     * Getter for date
     *
     * @return
     */
    public Date getDate() {
        return date;
    }

    /**
     * Setter for date
     * @param date
     */
    public void setDate(Date date) {
        this.date = date;
    }

    /**
     * Getter for time
     * @return
     */
    public String getTime() {
        return time;
    }

    /**
     * Setter for Time
     * @param time
     */
    public void setTime(String time) {
        this.time = time;
    }

    /**
     * Getter for courtId
     * @return
     */
    public int getCourtId() {
        return courtId;
    }

    /**
     * Setter for courtId
     * @param courtId
     */
    public void setCourtId(int courtId) {
        this.courtId = courtId;
    }

    /**
     * Getter for judge
     * @return
     */
    public String getJudge() {
        return judge;
    }

    /**
     * Setter for judge
     * @param judge
     */
    public void setJudge(String judge) {
        this.judge = judge;
    }


}