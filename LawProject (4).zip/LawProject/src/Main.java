import edu.psu.ist.controller.CaseListController;
import edu.psu.ist.controller.LoginController;

public class Main {
    public static void main(String[] args) {
        new LoginController();
        System.out.println("Hello world!");
    }
}