Initial Login Credentials Login is Case Sensitive:
Credentials:


Username:
admin


Password:
admin






Username:
User


Password:
userpassword










Team-Member ID
	Team-Member Name
	Percentage Efforts in Particular Assignment
	Brief of Efforts in the Tasks Contribution


	djw5853
	David Wang
	25 %
	Access Control function, UI, Views
	sbt5332
	Spencer Thomas
	25 %
	UI, Controllers, Model, Case view
	ams10251
	Ana Sharma
	25 %
	UI, Documents, Model
	jmw7394
	Josh Wolfel
	25 %
	UI, Calendar, Model